export class AppConfiguration{
    restAPIURL:string;
}