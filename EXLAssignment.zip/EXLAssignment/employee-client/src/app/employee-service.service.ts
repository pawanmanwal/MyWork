import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { AppConfiguration } from './app-configuration';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {


  restAPIURL: string;
  constructor(private http: HttpClient, private appConfig: AppConfiguration) {
    this.restAPIURL = appConfig.restAPIURL;
  }
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      alert('Some error occured while subscribing to Rest API. Please verify the URL and make sure that Rest services are up and running');
      console.error('Server Side Error :', errorResponse);
    }
    return throwError('There is a problem with the service. We are notified & working on it. Please try again later.');
  }

  public doRegistration(employee): Observable<Object> {
    return this.http.post(this.restAPIURL + "create", employee, { responseType: 'text' as 'json' }).pipe(catchError(this.handleError));
  }

  public getUsers() {
    return this.http.get(this.restAPIURL + "getAllUsers");
  }

  public getEmployees(employee): Observable<Employee> {
    return this.http.post(this.restAPIURL + "employeeSearch", employee).pipe(catchError(this.handleError));
  }

}
