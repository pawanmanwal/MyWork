export class Employee{
    constructor(
        firstName:string,
        lastName:string,
        jobTitle:string,
        startDate:Date,
        endDate:Date
    ){}
}